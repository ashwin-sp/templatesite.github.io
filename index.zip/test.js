

// const serialport = new SerialPort({ path: 'COM6', baudRate: 300000 })

// const file = fs.readFileSync("fileToSend.txt")
// serialport.write(file)

